import axios from 'axios';  // Axios para realizar solicitudes HTTP
import Constants from 'expo-constants'; // Para obtener la clave API desde las configuraciones de Expo

// Definimos la clave API y la URL base de la API de WeatherAPI
const API_KEY = Constants.expoConfig.extra.weatherApiKey; // Obtenemos la clave API desde las configuraciones de Expo
const BASE_URL = 'http://api.weatherapi.com/v1'; // URL base para acceder a la API de WeatherAPI

/*
 * Función asincrónica para obtener datos del clima de una ciudad.
 * @param {string} city - El nombre de la ciudad para la cual se desea obtener el clima.
 * @returns {object} - Los datos del clima de la ciudad en formato JSON.
 * @throws {Error} - Lanza un error si la solicitud a la API falla.
 */
export const getWeather = async (city) => {
  try {
    // Realizamos una solicitud GET a la API de WeatherAPI
    const response = await axios.get(`${BASE_URL}/current.json`, {
      params: {
        key: API_KEY, // Usamos la clave API para autenticar la solicitud
        q: city,  // El parámetro 'q' es el nombre de la ciudad
      },
    });

    // Devolvemos los datos obtenidos de la API
    return response.data;
  } catch (error) {
    // Si ocurre un error, lo registramos en la consola
    console.error("Error fetching weather data: ", error);
    throw error;
  }
};
