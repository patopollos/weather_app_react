import React, { useState, useEffect } from 'react';  // React y hooks
import { View, Text, TextInput, StyleSheet, Dimensions, ScrollView, TouchableOpacity, Modal, Image, ImageBackground } from 'react-native';
import { getWeather } from './WeatherService'; // Importamos la función para obtener los datos del clima desde el archivo WeatherService

// Obtenemos el ancho de la pantalla
const { width } = Dimensions.get("window");

export default function App() {
  // Estado para almacenar las ciudades disponibles en la aplicación
  const [cities] = useState([
    { name: 'London', id: 1 },
    { name: 'New York', id: 2 },
    { name: 'Tokyo', id: 3 },
    { name: 'Rusia', id: 4 },
    { name: 'Ottawa', id: 5 },
    { name: 'Mexico', id: 6 },
    { name: 'Boston', id: 7 },
    { name: 'Bogota', id: 8 },
    { name: 'Italia', id: 9 },
    { name: 'Paris', id: 10 },
    { name: 'Berlin', id: 11 },
    { name: 'Madrid', id: 12 },
    { name: 'Lisboa', id: 13 },
    { name: 'India', id: 14 },
    { name: 'Hawai', id: 15 },
    { name: 'Francia', id: 16 },
    { name: 'Venecia', id: 17 },
    { name: 'Alaska', id: 18 },
    { name: 'Seul', id: 19 },
    { name: 'Osaka', id: 20 },
    { name: 'Chicago', id: 21 },
    { name: 'Pekin', id: 22 },
    { name: 'Sao Paulo', id: 23 },
    { name: 'Dallas', id: 24 },
    { name: 'Canton', id: 25 },
    { name: 'Toronto', id: 26 },
    { name: 'Frankfurt', id: 27 },
    { name: 'Houston', id: 28 },
    { name: 'Roma', id: 29 },
    { name: 'Filadelfia', id: 30 },
    { name: 'Yakarta', id: 31 },
    { name: 'Hamburgo', id: 32 },
    { name: 'San Francisco', id: 33 },
    { name: 'Mumbai', id: 34 },
    { name: 'Singapur', id: 35 },
    { name: 'Hong Kong', id: 36 },
    { name: 'Amsterdam', id: 37 },
    { name: 'Estambul', id: 38 },
    { name: 'Buenos Aires', id: 40 },
    { name: 'Bruselas', id: 41 },
    { name: 'Sidney', id: 42 },
    { name: 'Munich', id: 43 },
    { name: 'Miami', id: 44 },
    { name: 'Rio de Janeiro', id: 45 },
    { name: 'Montreal', id: 46 },
    { name: 'Ginebra', id: 47 },
    { name: 'Estocolmo', id: 48 },
    { name: 'Dublin', id: 49 },
    { name: 'San Marino', id: 50 },
    { name: 'Santiago', id: 51 },
    { name: 'Johannesburgo', id: 52 },
    { name: 'Barcelona', id: 53 },
    { name: 'Baltimore', id: 54 },
    { name: 'Stuttgart', id: 55 },
    { name: 'Abu Dabi', id: 56 },
    { name: 'Zurich', id: 57 },
    { name: 'Vancouver', id: 58 },
    { name: 'Calcuta', id: 59 },
    { name: 'Brasilia', id: 60 },
    { name: 'El Cairo', id: 61 },
    { name: 'Napoles', id: 62 },
    { name: 'Lima', id: 63 },
    { name: 'Lyon', id: 64 },
    { name: 'Praga', id: 65 },
    { name: 'Liverpool', id: 66 },
    { name: 'Valencia', id: 67 },
    { name: 'Hiroshima', id: 68 },
    { name: 'Atenas', id: 69 },
    { name: 'Guadalajara', id: 70 },
    { name: 'Leon', id: 71 },
    { name: 'Jerusalen', id: 72 },
    { name: 'Ciudad del Cabo', id: 73 },
    { name: 'San Luis', id: 74 },
    { name: 'Budapest', id: 75 },
    { name: 'Venecia', id: 76 },
    { name: 'Sevilla', id: 77 },
    { name: 'Kuwait', id: 78 },
    { name: 'Nairobi', id: 79 },
    { name: 'Sacramento', id: 80 },
    { name: 'Orlando', id: 81 },
    { name: 'Puebla', id: 82 },
    { name: 'Casablanca', id: 83 },
    { name: 'Malaga', id: 84 },
    { name: 'Quebec', id: 85 },
    { name: 'Manchester', id: 86 },
    { name: 'San Antonio', id: 87 },
    { name: 'Cordoba', id: 88 },
    { name: 'Salvador', id: 89 },
    { name: 'Las Vegas', id: 90 },
    { name: 'Tijuana', id: 91 },
    { name: 'Palermo', id: 92 },
    { name: 'Porto Alegre', id: 93 },
    { name: 'Queretaro', id: 94 },
    { name: 'Burdeos', id: 95 },
    { name: 'Montevideo', id: 96 },
    { name: 'Medellin', id: 97 },
    { name: 'Alejandria', id: 98 },
    { name: 'Florencia', id: 99 },
    { name: 'Luxemburgo', id: 100 },
    
  ]);
  const [searchQuery, setSearchQuery] = useState('');  // Estado para almacenar la búsqueda de ciudad
  const [weatherData, setWeatherData] = useState(null);  // Estado para almacenar los datos del clima de la ciudad seleccionada
  const [modalVisible, setModalVisible] = useState(false); // Estado para controlar la visibilidad del modal

  // UseEffect para obtener los datos del clima cuando se carga la aplicación
  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getWeather('London'); // Obtiene datos del clima para Londres
        setWeatherData(data);  // Guarda los datos del clima en el state
      } catch (error) {
        console.error("Error fetching weather data: ", error);  // Maneja el error si no se puede obtener el clima
      }
    };
    fetchData();  // Llama a la función para obtener los datos
  }, []);  // Solo se ejecuta una vez cuando el componente se monta

  // Función para manejar el clic en una ciudad
  const handleCityClick = async (city) => {
    const data = await getWeather(city.name); // Consultamos el clima de la ciudad seleccionada
    setWeatherData(data); // Actualiza el estado con los nuevos datos
    setModalVisible(true); // Mostramos el modal
  };
  
  // Filtra las ciudades basadas en la consulta de búsqueda
  const filteredCities = cities.filter(city => city.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    
    //<View style={styles.container}>
      <ImageBackground source={require('./assets/fondo_sky.png')} style={styles.container}>
      {/* Ícono de la aplicación */}
      <Image
          source={require('./assets/logo_clima.png')}
          style={styles.icon}
        />            
        
      {/* titulo y subtitulo */}
      <Text style={styles.title}>Weather App</Text>
      <Text style={styles.subtitle}>Consulta el clima actual de 100 ciudades del mundo</Text>     

      {/* Campo de búsqueda */}
      <TextInput
        style={styles.searchInput}
        placeholder="Buscar ciudad..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      {/* El ScrollView permite que las ciudades se muestren en una lista desplazable.
        Para mostrar las ciudades en 2 columnas, se usa un contenedor con estilo `cityRow` que 
        tiene `flexDirection: 'row'` para organizar los elementos horizontalmente.
        El uso de `flexWrap: 'wrap'` asegura que las ciudades se envuelvan y se distribuyan en 
        dos columnas dentro del ScrollView. */}
      <ScrollView contentContainerStyle={styles.cityList}>
        <View style={styles.cityRow}>
          {filteredCities.map((city) => (
            <TouchableOpacity key={city.id} style={styles.cityCard} onPress={() => handleCityClick(city)}>
              <Text style={styles.cityText}>{city.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Modal para mostrar la información del clima de la ciudad */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
        transparent={true}
      >
        {weatherData && (
          <View style={styles.modalBackground}>
            <View style={styles.modalContainer}>
              {/* Mostrar el icono  del clima desde la API */}
              <Image
                source={{ uri: `https:${weatherData.current.condition.icon}` }}
                style={styles.weatherIcon}
              />
              <Text style={styles.cityName}>
                {weatherData.location.name}
              </Text>
              <Text style={styles.temperature}>
                {weatherData.current.temp_c}°C
              </Text>
              <Text style={styles.condition}>
                {weatherData.current.condition.text}
              </Text>              
              <Text style={styles.details}>
                Humidity: {weatherData.current.humidity}%
              </Text>
              <Text style={styles.details}>
                Wind Speed: {weatherData.current.wind_kph} kph
              </Text>
              <Text style={styles.details}>
                Local Time: {weatherData.location.localtime}
              </Text>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Text style={styles.buttonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </Modal>
      </ImageBackground>
    //</View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    //backgroundColor: '#f0f8ff',  // Fondo azul claro para el clima, por si falla la imagen de fondo
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    //backgroundImage: 'url("https://images4.alphacoders.com/679/679373.jpg")',  // Fondo con imagen del cielo
    //backgroundSize: 'cover',
    //backgroundPosition: 'center',
  },
  
  icon: {
    width: 60,  // Ajusta el tamaño del ícono
    height: 60,  // Ajusta el tamaño del ícono
    marginTop: 10
    
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#1D3557',
    marginBottom: 20,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1D3557',
    marginBottom: 20,
    textAlign: 'center',
  },
  searchInput: {
    width: '80%',
    height: 40,
    borderWidth: 1,
    paddingHorizontal: 10,
    marginBottom: 10,
    borderRadius: 5,
    backgroundColor: '#ffffff',
    fontSize: 16,
  },
  cityList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  cityRow: {
    flexDirection: 'row',  // Esto organiza los elementos horizontalmente
    flexWrap: 'wrap',  // Permite que los elementos se envuelvan en la siguiente línea cuando el espacio se llena
    justifyContent: 'center',  // Centra las columnas
    width: '100%',  // Asegura que el contenedor ocupe el ancho completo
  },
  cityCard: {
    width: width * 0.35,
    height: 70,
    backgroundColor: '#FFEB3B',
    margin: 5,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    //shadowColor: '#000',
    //shadowOffset: { width: 0, height: 2 },
    //shadowOpacity: 0.1,
    //shadowRadius: 4,
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', // Reemplazo de shadow por boxShadow
    elevation: 3,
  },
  cityText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1D3557',
  },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Fondo oscuro detrás del modal
  },
  modalContainer: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 12,
    width: width * 0.75, // Modal ajustado a un 75% del ancho
    alignItems: 'center',
    //shadowColor: '#000',
    //shadowOffset: { width: 0, height: 2 },
    //shadowOpacity: 0.1,
    //shadowRadius: 4,
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', // Reemplazo de shadow por boxShadow
    elevation: 5,
  },
  weatherDetails: {
    alignItems: 'center',
  },
  weatherIcon: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  cityName: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  temperature: {
    fontSize: 40,
  },
  condition: {
    fontSize: 18,
  },
  details: {
    fontSize: 16,
  },
  closeButton: {
    backgroundColor: '#FF5733',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
});